import os, glob, math, random, warnings
from pathlib import Path
import numpy as np
import xarray as xr
import torch
from torch.utils.data import Dataset

def _open_mf(paths):
    files = []
    for p in paths:
        files.extend(glob.glob(p))
    if not files:
        raise FileNotFoundError(f"No files matched: {paths}")
    # We keep chunks small; user can tune with dask if needed.
    ds = xr.open_mfdataset(files, combine='by_coords', engine='netcdf4')
    return ds

def _rescale_reflectance(arr, scale=10000.0):
    a = np.asarray(arr, dtype=np.float32) / float(scale)
    # clamp to [0,1.2] to allow minor over-range
    return np.clip(a, 0.0, 1.2)

class AlphaEarthGapfillDataset(Dataset):
    """
    Expects three NetCDF groups (or separate files):
      - Landsat: high-res grid (y,x,bands,time,site) or similar
      - MODIS: coarse daily (y_c,x_c,bands,time,site)
      - Embeddings: high-res per-pixel embeddings (y,x,emb_dim,year,site)
    You can adapt variable names via args.
    """
    def __init__(self,
                 landsat_paths,
                 modis_paths,
                 embed_paths,
                 landsat_var='landsat_reflectance',
                 modis_var='modis_reflectance',
                 embed_var='embeddings',
                 bands=('red','nir','green','blue'),
                 site_exclude=None,
                 site_include=None,
                 year_exclude=None,
                 year_include=None,
                 patch=128,
                 jitter_days=0,
                 simulate_modis_gaps=True,
                 modis_drop_prob=0.2,
                 seed=42):
        super().__init__()
        random.seed(seed); np.random.seed(seed)
        self.ls_ds = _open_mf(landsat_paths)
        self.md_ds = _open_mf(modis_paths)
        self.eb_ds = _open_mf(embed_paths)

        self.ls_var = landsat_var
        self.md_var = modis_var
        self.eb_var = embed_var
        self.bands = list(bands)
        self.patch = patch
        self.jitter_days = jitter_days
        self.sim_modis = simulate_modis_gaps
        self.modis_drop_prob = modis_drop_prob

        # Expect coords: site, time (datetime64), band dimension named consistently
        # Normalize naming
        for ds in [self.ls_ds, self.md_ds, self.eb_ds]:
            if 'site' not in ds.dims and 'site' in ds.coords:
                pass
        # Filter sites/years
        sites = list(self.ls_ds['site'].values) if 'site' in self.ls_ds.coords else ['global']
        years = np.array([int(str(t)[:4]) for t in self.ls_ds['time'].values])
        self.samples = []  # (site, date_index)

        for i, t in enumerate(self.ls_ds['time'].values):
            y = int(str(t)[:4])
            if year_include and y not in year_include: continue
            if year_exclude and y in year_exclude: continue
            # Only keep times where Landsat label exists
            ls_t = self.ls_ds[self.ls_var].sel(time=t)
            if np.all(np.isnan(ls_t)):
                continue
            self.samples.append(i)

        self.time_index = self.ls_ds['time'].values

    def __len__(self):
        return len(self.samples)

    def _choose_patch(self, H, W):
        ps = self.patch
        y0 = 0 if H<=ps else np.random.randint(0, H-ps)
        x0 = 0 if W<=ps else np.random.randint(0, W-ps)
        return slice(y0, y0+ps), slice(x0, x0+ps)

    def __getitem__(self, idx):
        i = self.samples[idx]
        t = self.time_index[i]
        y = int(str(t)[:4])
        # Landsat (label) at t
        ls = self.ls_ds[self.ls_var].sel(time=t)  # [band,y,x]
        # Ensure band order
        ls = ls.sel(band=[b for b in self.bands if b in ls['band'].values])
        ls_np = _rescale_reflectance(ls.values)  # [B,H,W]

        # MODIS at t → upsample to Landsat grid via xarray
        md = self.md_ds[self.md_var].sel(time=t)
        # Basic nearest/bilinear upsample to Landsat coords
        md_up = md.interp_like(ls, method='linear')
        md_np = _rescale_reflectance(md_up.values)  # [B,H,W]

        # Embeddings for year y (assumes 'year' coord)
        if 'year' in self.eb_ds.coords:
            eb = self.eb_ds[self.eb_var].sel(year=y)
        else:
            eb = self.eb_ds[self.eb_var]
        # Align to LS grid if needed
        try:
            eb_al = eb.interp_like(ls, method='nearest')
        except Exception:
            eb_al = eb
        eb_np = np.asarray(eb_al.values, dtype=np.float32)  # [E,H,W]

        # Optional MODIS dropouts to simulate clouds
        if self.sim_modis and random.random() < self.modis_drop_prob:
            h, w = md_np.shape[-2:]
            bh = max(16, h//6); bw = max(16, w//6)
            y0 = np.random.randint(0, h-bh); x0 = np.random.randint(0, w-bw)
            md_np[:, y0:y0+bh, x0:x0+bw] = np.nan

        # Patch
        H, W = ls_np.shape[-2:]
        ys, xs = self._choose_patch(H, W)
        ls_np = ls_np[:, ys, xs]
        md_np = md_np[:, ys, xs]
        eb_np = eb_np[:, ys, xs]

        # Replace remaining NaNs in inputs with local medians
        def nan_to_med(a):
            if np.isnan(a).any():
                med = np.nanmedian(a, axis=(-2,-1), keepdims=True)
                a = np.where(np.isnan(a), med, a)
            return a
        md_np = nan_to_med(md_np)
        eb_np = nan_to_med(eb_np)

        # Features: [MODIS bands + reduced embeddings + time encodings]
        # Time encodings: DOY sin/cos
        import pandas as pd
        dt = pd.to_datetime(str(t))
        doy = dt.timetuple().tm_yday
        sin = np.full((1, ls_np.shape[1], ls_np.shape[2]), np.sin(2*np.pi*doy/365.0), dtype=np.float32)
        cos = np.full((1, ls_np.shape[1], ls_np.shape[2]), np.cos(2*np.pi*doy/365.0), dtype=np.float32)

        x = np.concatenate([md_np, eb_np, sin, cos], axis=0)  # [C_in,H,W]
        y = ls_np  # [C_out,H,W]

        return torch.from_numpy(x), torch.from_numpy(y)

# Sundai Hackathon — AlphaEarth-Conditioned Gap Filling (30 m daily)

**Goal:** Predict **daily 30 m** Landsat-like reflectance using **coarse daily MODIS** + **AlphaEarth embeddings** (same-year) as context. 
This scaffold is optimized for **patch-level training**, **leave-site/year-out validation**, and quick iteration during a hackathon.

---

## What’s in here

- **train.py** — Train a compact UNet to map inputs → 30 m reflectance per band.
- **infer.py** — Run inference to produce daily 30 m stacks over a site/date range.
- **data/dataset.py** — NetCDF readers for Landsat/MODIS/Embeddings + dynamic resampling to the Landsat grid, cloud simulation, patch sampling.
- **data/splits.py** — Site/year split utilities (LOSO, LOYO). 
- **models/unet.py** — Lightweight UNet with dynamic input/output channels and 1×1 bottleneck for high-dim embeddings.
- **baselines/starfm_lite.py** — Simple STARFM-like fusion for comparison.
- **metrics.py / losses.py** — RMSE/MAE/SSIM/SAM; L1 + spectral-angle loss.
- **requirements.txt** — Minimal deps.

**Assumptions (edit in dataset config):**
- NetCDFs contain variables for Landsat reflectance (30 m), MODIS reflectance (500 m daily), and AlphaEarth embeddings (per-pixel vectors per year).
- You have **~60 sites**; each site has coordinates/grids. AlphaEarth embeddings are resampled/aligned to the Landsat grid (or will be by you; we provide code hooks to resample if needed).

---

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Example: train on 2019–2020 for most sites; validate on site 'TX03' in 2021
python train.py   --landsat_paths /data/landsat/*.nc   --modis_paths /data/modis/*.nc   --embed_paths /data/alphaearth/*.nc   --out_dir ./runs/exp1   --val_site TX03   --val_year 2021   --bands red nir green blue swir1 swir2   --embed_var embeddings   --landsat_var landsat_reflectance   --modis_var modis_reflectance   --patch 128   --batch 8   --epochs 10
```

**Inference (daily 30 m stack for a site/year)**
```bash
python infer.py   --ckpt ./runs/exp1/best.pt   --landsat_paths /data/landsat/*.nc   --modis_paths /data/modis/*.nc   --embed_paths /data/alphaearth/*.nc   --site TX03 --year 2021   --out_dir ./predictions/TX03_2021
```

---

## Validation protocol (recommended)

1. **Leave-one-site-out (LOSO):** Train on N–1 sites across all years; validate on the held-out site (all years).  
2. **Leave-one-year-out (LOYO):** Train on all sites except a target year; validate on that year across sites.  
3. **Outside domain test:** pick sites/years with extreme phenology or disturbance not in train.

Metrics: **RMSE/MAE** per band, **SSIM** (RGB composite), **Spectral Angle Mapper (SAM)**, and temporal profile error on NDVI/EVI.  
Compare against **STARFM-lite** baseline provided here.

---

## Model idea (concise)

- **Inputs:** 
  - `MODIS(t)` upsampled to Landsat grid (7 bands typical).
  - **AlphaEarth embeddings** (project to 8–16 channels via 1×1 conv).
  - Optional scalars per-pixel: **day-of-year (sin/cos)**, **time since last/next Landsat**, **lat/lon (sin/cos)**.

- **Backbone:** Small **UNet** (GroupNorm, SiLU), receptive field tuned for 128×128 patches.

- **Loss:** `L = 0.8 * L1 + 0.2 * SAM` (band-wise), optional SSIM term on RGB proxy.

- **Uncertainty:** enable **MC dropout** at inference (`--mc_samples N`) to get mean/σ.

---

## Data notes

- Respect reflectance **scale factors** and **valid ranges** (e.g., 0–10000 → /10000).
- Mask clouds/shadows in Landsat labels for loss computation only; the model predicts the unobscured surface reflectance.
- We simulate missing **MODIS** via random block/drop masks (clouds) during training.

---

## Baseline

Run `baselines/starfm_lite.py` to generate predictions from MODIS deltas and compare metrics; use it as a sanity floor.

---

## Woodwell hook

If you want to test downstream: export predicted daily 30 m NDVI/EVI cubes and swap them into the **Woodwell grassland carbon model** pipeline; record delta in modeled flux against the traditional fusion input.

---

## Next (post-hackathon) 

- Replace TV-L1 with learned VFI (RIFE) for short-gap sharpness (hybrid).
- Add **continuous-time encoding** (Fourier Time2Vec) for arbitrary Δt generalization.
- Train a small **3D UNet** over (t−k…t+k) windows to denoise temporal artifacts.

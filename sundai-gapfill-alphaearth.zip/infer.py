import argparse, os, math, json
import numpy as np
import torch
import xarray as xr
from tqdm import tqdm
from models.unet import UNetSmall

def parse():
    ap = argparse.ArgumentParser()
    ap.add_argument('--ckpt', required=True)
    ap.add_argument('--landsat_paths', nargs='+', required=True)
    ap.add_argument('--modis_paths', nargs='+', required=True)
    ap.add_argument('--embed_paths', nargs='+', required=True)
    ap.add_argument('--landsat_var', default='landsat_reflectance')
    ap.add_argument('--modis_var', default='modis_reflectance')
    ap.add_argument('--embed_var', default='embeddings')
    ap.add_argument('--site', required=True)
    ap.add_argument('--year', type=int, required=True)
    ap.add_argument('--out_dir', required=True)
    return ap.parse_args()

def main():
    args = parse(); os.makedirs(args.out_dir, exist_ok=True)
    ck = torch.load(args.ckpt, map_location='cpu')
    model = UNetSmall(ck['in_ch'], ck['out_ch']); model.load_state_dict(ck['model']); model.eval()
    device = 'cuda' if torch.cuda.is_available() else 'cpu'; model.to(device)

    # Simplified site/year loader; users should adapt to actual coords
    ls = xr.open_mfdataset(args.landsat_paths, combine='by_coords')[args.landsat_var]
    md = xr.open_mfdataset(args.modis_paths, combine='by_coords')[args.modis_var]
    eb = xr.open_mfdataset(args.embed_paths, combine='by_coords')[args.embed_var]
    ls_site = ls.sel(site=args.site)
    md_site = md.sel(site=args.site)
    eb_site = eb.sel(site=args.site)
    times = [t for t in ls_site['time'].values if str(t).startswith(str(args.year))]

    # Predict per day (where Landsat might be missing)
    for t in tqdm(times, desc='Predict daily 30 m'):
        doy = int(str(t)[5:7])*30  # placeholder; better to compute true DOY
        mod = md_site.sel(time=t).interp_like(ls_site.sel(time=t, method='nearest'), method='linear')
        emb = eb_site.sel(year=args.year)
        # Align
        emb = emb.interp_like(ls_site, method='nearest')
        # Stack inputs
        ls_t = ls_site.sel(time=t)
        try:
            import pandas as pd
            dt = pd.to_datetime(str(t)); from math import pi, sin, cos
            sin_d = np.sin(2*np.pi*dt.timetuple().tm_yday/365.0)
            cos_d = np.cos(2*np.pi*dt.timetuple().tm_yday/365.0)
        except Exception:
            sin_d, cos_d = 0.0, 1.0
        x = np.concatenate([np.nan_to_num(mod.values, nan=np.nanmedian(mod.values)),
                            np.nan_to_num(emb.values, nan=np.nanmedian(emb.values)),
                            np.full((1,)+ls_t.shape[-2:], sin_d, dtype=np.float32),
                            np.full((1,)+ls_t.shape[-2:], cos_d, dtype=np.float32)], axis=0)
        xb = torch.from_numpy(x).unsqueeze(0).to(device, dtype=torch.float32)
        with torch.no_grad():
            yhat = model(xb)[0].cpu().numpy()
        # Save as NetCDF slice
        da = xr.DataArray(yhat, dims=('band','y','x'), coords={'band': ls_site['band'].values, 'y': ls_site['y'], 'x': ls_site['x']})
        da.to_netcdf(os.path.join(args.out_dir, f'pred_{args.site}_{args.year}_{str(t)[:10].replace("-","")}.nc'))

if __name__ == '__main__':
    main()

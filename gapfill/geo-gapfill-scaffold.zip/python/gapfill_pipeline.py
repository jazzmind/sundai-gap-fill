#!/usr/bin/env python3
# Gap-fill pipeline scaffold: optical-flow (short gaps), STARFM-lite (fusion), Kalman smoother (uncertainty).
# Assumes daily stacks exported from GEE (HLS + MODIS + ERA5) at common grid.

import os, glob, argparse, warnings
from pathlib import Path
import numpy as np
import pandas as pd
import xarray as xr
import rioxarray as rxr
import rasterio
from tqdm import tqdm

from skimage.registration import optical_flow_tvl1
from skimage.transform import warp
from skimage.metrics import structural_similarity as ssim
from sklearn.linear_model import LinearRegression

try:
    from pykalman import KalmanFilter
    HAVE_PYK = True
except Exception:
    HAVE_PYK = False
    warnings.warn("pykalman not installed; Kalman smoother will be skipped.")

def read_stack_dir(d):
    files = sorted(glob.glob(os.path.join(d, "*.tif")))
    if not files:
        raise FileNotFoundError(f"No GeoTIFFs found in {d}")
    arrs, dates = [], []
    for f in files:
        stem = Path(f).stem
        # Expect date in filename like *_YYYYMMDD.tif
        parts = stem.split("_")
        dstr = ""
        for p in parts[::-1]:
            digits = "".join([c for c in p if c.isdigit()])
            if len(digits) >= 8:
                dstr = digits[-8:]
                break
        try:
            dt = pd.to_datetime(dstr, format="%Y%m%d")
        except Exception:
            dt = None
        da = rxr.open_rasterio(f, masked=True).squeeze(drop=True)
        da = da.astype("float32")
        if "band" not in da.dims and da.ndim == 2:
            da = da.expand_dims("band").assign_coords(band=["band1"])
        arrs.append(da)
        dates.append(dt)
    stack = xr.concat(arrs, dim="time")
    stack = stack.assign_coords(time=("time", dates))
    return stack

def compute_ndvi(ds, red_name="red", nir_name="nir"):
    bands = [str(b) for b in ds.band.values]
    if red_name in bands and nir_name in bands:
        red = ds.sel(band=red_name)
        nir = ds.sel(band=nir_name)
        ndvi = (nir - red) / (nir + red + 1e-6)
        ndvi = ndvi.clip(min=-1, max=1)
        ndvi = ndvi.assign_coords(band="ndvi")
        return xr.concat([ds, ndvi], dim="band")
    return ds

def tvl1_flow(im0, im1):
    # Compute TV-L1 optical flow from im0 -> im1; expects 2D arrays [y,x] normalized 0..1
    v, u = optical_flow_tvl1(im0, im1)  # returns (vy, vx)
    return u, v

def warp_towards(im, flow_u, flow_v, frac):
    # Warp image toward target time by scaling the flow by 'frac'.
    h, w = im.shape
    grid_y, grid_x = np.mgrid[0:h, 0:w]
    coords = np.array([grid_y + frac*flow_v, grid_x + frac*flow_u])
    warped = warp(im, coords, preserve_range=True, mode='edge')
    return warped

def atfi_interpolate(im0, im1, alpha):
    # Arbitrary-time frame interpolation using TV-L1 flow on a single 2D channel.
    m = np.nanmean([im0, im1])
    s = np.nanstd([im0, im1]) + 1e-6
    a0 = (im0 - m) / s
    a1 = (im1 - m) / s
    u01, v01 = tvl1_flow(a0, a1)
    u10, v10 = tvl1_flow(a1, a0)
    w0 = warp_towards(im0, u01, v01, alpha)
    w1 = warp_towards(im1, u10, v10, 1.0 - alpha)
    fb_cons = np.exp(- (u01 + u10)**2 - (v01 + v10)**2)
    fb_cons = (fb_cons - fb_cons.min()) / (fb_cons.max() - fb_cons.min() + 1e-6)
    beta = np.clip(fb_cons, 0.2, 0.8)
    out = beta * w0 + (1.0 - beta) * w1
    return out

def starfm_lite(hls_t0, hls_t1, mcd_t0, mcd_t1, mcd_t):
    # Very simplified STARFM-like fusion with linear regressions.
    def fit_predict(hls, mcd, mcd_t):
        h = hls.values.ravel()
        m = mcd.values.ravel()
        mask = np.isfinite(h) & np.isfinite(m)
        if mask.sum() < 1000:
            return xr.zeros_like(hls) * np.nan
        X = m[mask][:, None]
        y = h[mask]
        lr = LinearRegression().fit(X, y)
        pred = lr.predict(mcd_t.values.ravel()[:,None]).reshape(hls.shape)
        return xr.DataArray(pred, coords=hls.coords, dims=hls.dims)
    p0 = fit_predict(hls_t0, mcd_t0, mcd_t)
    p1 = fit_predict(hls_t1, mcd_t1, mcd_t)
    w0, w1 = 0.5, 0.5
    if "time" in hls_t0.coords and "time" in hls_t1.coords and "time" in mcd_t.coords:
        t = pd.to_datetime(str(mcd_t.time.values))
        t0 = pd.to_datetime(str(hls_t0.time.values))
        t1 = pd.to_datetime(str(hls_t1.time.values))
        if t1 != t0:
            w1 = (t - t0) / (t1 - t0)
            w0 = 1.0 - w1
    pred = w0 * p0 + w1 * p1
    return pred

def kalman_fill(ndvi_series):
    # 1D Kalman smoother per pixel across time; returns smoothed series and variance.
    y = ndvi_series.copy()
    mask = ~np.isfinite(y)
    if np.all(mask):
        return y, np.full_like(y, np.nan)
    y[mask] = np.nanmean(y[~mask])
    if not HAVE_PYK:
        return y, np.full_like(y, np.nan)
    kf = KalmanFilter(
        transition_matrices=np.array([[1]]),
        observation_matrices=np.array([[1]]),
        transition_covariance=np.array([[1e-3]]),
        observation_covariance=np.array([[1e-2]]),
        initial_state_mean=y[~np.isnan(y)][0],
        initial_state_covariance=1.0
    )
    smoothed_state, smoothed_cov = kf.smooth(y)
    return smoothed_state.ravel(), smoothed_cov.ravel()

def parse_args():
    ap = argparse.ArgumentParser(description="Gap-fill scaffold")
    ap.add_argument("--hls_dir", required=True)
    ap.add_argument("--modis_dir", required=True)
    ap.add_argument("--era5_dir", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--method", choices=["oflow","starfm","kalman"], default="oflow")
    ap.add_argument("--index", choices=["NDVI","band"], default="NDVI")
    ap.add_argument("--band_name", default="red", help="Used when index=band")
    return ap.parse_args()

def main():
    args = parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    print("Loading HLS...")
    hls = read_stack_dir(args.hls_dir)
    if "band" not in hls.dims:
        hls = hls.expand_dims("band").assign_coords(band=["band1"])

    if "ndvi" not in [str(b) for b in hls.band.values]:
        try:
            hls = hls.assign_coords(band=[str(b) for b in hls.band.values])
            hls = compute_ndvi(hls, "red", "nir")
        except Exception:
            pass

    print("Loading MODIS...")
    mcd = read_stack_dir(args.modis_dir)
    print("Loading ERA5...")
    era = read_stack_dir(args.era5_dir)

    # Align times
    common_dates = pd.Index(hls.time.values).intersection(pd.Index(mcd.time.values)).intersection(pd.Index(era.time.values))
    hls = hls.sel(time=common_dates)
    mcd = mcd.sel(time=common_dates)
    era = era.sel(time=common_dates)

    # Channel selection
    if args.index.upper() == "NDVI" and "ndvi" in [str(b) for b in hls.band.values]:
        ch = "ndvi"
    else:
        ch = args.band_name if args.band_name in [str(b) for b in hls.band.values] else str(hls.band.values[0])
    print(f"Processing channel: {ch}")

    # Detect gaps
    target_dates = []
    for t in hls.time.values:
        im = hls.sel(time=t, band=ch)
        if np.isnan(im.values).all():
            target_dates.append(pd.to_datetime(str(t)))
    print(f"Gaps detected: {len(target_dates)}")

    times = pd.to_datetime(hls.time.values)
    def neighbors(t):
        before = times[times < t]
        after = times[times > t]
        t0 = before.max() if len(before) else None
        t1 = after.min() if len(after) else None
        return t0, t1

    # Reference profile for GeoTIFF output
    ref_path = sorted(glob.glob(os.path.join(args.hls_dir, "*.tif")))[0]
    ref = rxr.open_rasterio(ref_path)

    for t in tqdm(target_dates, desc="Interpolating"):
        t0, t1 = neighbors(t)
        if t0 is None or t1 is None:
            continue
        im0 = hls.sel(time=t0, band=ch).values
        im1 = hls.sel(time=t1, band=ch).values

        if args.method == "oflow":
            alpha = (t - t0) / (t1 - t0)
            pred = atfi_interpolate(im0, im1, alpha)
        elif args.method == "starfm":
            m0 = mcd.isel(band=0).sel(time=t0)
            m1 = mcd.isel(band=0).sel(time=t1)
            mt = mcd.isel(band=0).sel(time=t)
            h0 = hls.sel(time=t0, band=ch)
            h1 = hls.sel(time=t1, band=ch)
            pred_da = starfm_lite(h0, h1, m0, m1, mt)
            pred = pred_da.values
        else:
            # Kalman method is done for the whole series, skip per-gap action
            continue

        # Write filled image for this date
        arr = np.nan_to_num(pred, nan=np.nan)
        out_path = os.path.join(args.out_dir, f"interp_{t.strftime('%Y%m%d')}.tif")
        profile = ref.rio.profile
        profile.update(count=1, dtype="float32", compress="lzw")
        with rasterio.open(out_path, "w", **profile) as dst:
            dst.write(arr.astype("float32"), 1)

    # Global Kalman smoother (optional)
    if args.method == "kalman" and "ndvi" in [str(b) for b in hls.band.values] and HAVE_PYK:
        print("Running Kalman smoother on NDVI series...")
        ndvi = hls.sel(band="ndvi").values  # [time,y,x]
        T, H, W = ndvi.shape
        ndvi_sm = np.empty_like(ndvi)
        ndvi_var = np.empty_like(ndvi)
        for y in tqdm(range(H), desc="Kalman rows"):
            for x in range(W):
                series = ndvi[:, y, x]
                sm, var = kalman_fill(series)
                ndvi_sm[:, y, x] = sm
                ndvi_var[:, y, x] = var
        for i, t in enumerate(pd.to_datetime(hls.time.values)):
            out_path = os.path.join(args.out_dir, f"kalman_{t.strftime('%Y%m%d')}.tif")
            profile = ref.rio.profile
            profile.update(count=1, dtype="float32", compress="lzw")
            with rasterio.open(out_path, "w", **profile) as dst:
                dst.write(ndvi_sm[i].astype("float32"), 1)
        pd.DataFrame({
            "date": pd.to_datetime(hls.time.values).strftime("%Y-%m-%d"),
            "ndvi_mean": ndvi_sm.mean(axis=(1,2)),
            "ndvi_std": ndvi_sm.std(axis=(1,2))
        }).to_csv(os.path.join(args.out_dir, "kalman_summary.csv"), index=False)

if __name__ == "__main__":
    main()

import argparse, os, numpy as np, torch, xarray as xr
from tqdm import tqdm
from models.unet import UNetSmall

def parse():
    ap = argparse.ArgumentParser()
    ap.add_argument('--ckpt', required=True)
    ap.add_argument('--landsat_paths', nargs='+', required=True)
    ap.add_argument('--modis_paths',  nargs='+', required=True)
    ap.add_argument('--embed_paths',  nargs='+', required=True)
    ap.add_argument('--landsat_var', default='landsat_reflectance')
    ap.add_argument('--modis_var',   default='modis_reflectance')
    ap.add_argument('--embed_var',   default='embeddings')
    ap.add_argument('--site', required=True)
    ap.add_argument('--year', type=int, required=True)
    ap.add_argument('--out_dir', required=True)
    ap.add_argument('--gcs_auth', default='google_default')
    return ap.parse_args()

def main():
    args = parse(); os.makedirs(args.out_dir, exist_ok=True)
    ck = torch.load(args.ckpt, map_location='cpu')
    model = UNetSmall(ck['in_ch'], ck['out_ch']); model.load_state_dict(ck['model']); model.eval()
    device = 'cuda' if torch.cuda.is_available() else 'cpu'; model.to(device)

    if args.gcs_auth == 'google_default':
        backend_kwargs = {'storage_options': {'token': 'google_default'}}
    elif args.gcs_auth == 'anon':
        backend_kwargs = {'storage_options': {'token': None}}
    else:
        backend_kwargs = {'storage_options': {'token': args.gcs_auth}}

    ls = xr.open_mfdataset(args.landsat_paths, combine='by_coords', engine='h5netcdf', backend_kwargs=backend_kwargs)[args.landsat_var].sel(site=args.site)
    md = xr.open_mfdataset(args.modis_paths,  combine='by_coords', engine='h5netcdf', backend_kwargs=backend_kwargs)[args.modis_var].sel(site=args.site)
    eb = xr.open_mfdataset(args.embed_paths,  combine='by_coords', engine='h5netcdf', backend_kwargs=backend_kwargs)[args.embed_var].sel(site=args.site)

    times = [t for t in ls['time'].values if str(t).startswith(str(args.year))]
    import pandas as pd, numpy as np

    for t in tqdm(times, desc='Predict daily 30 m'):
        dt = pd.to_datetime(str(t)); sin_d = np.sin(2*np.pi*dt.timetuple().tm_yday/365.0); cos_d = np.cos(2*np.pi*dt.timetuple().tm_yday/365.0)
        ls_t = ls.sel(time=t)
        mod  = md.sel(time=t).interp_like(ls_t, method='linear')
        emb  = eb.sel(year=args.year) if 'year' in eb.coords else eb
        emb  = emb.interp_like(ls_t, method='nearest')

        x = np.concatenate([np.nan_to_num(mod.values, nan=np.nanmedian(mod.values)),
                            np.nan_to_num(emb.values, nan=np.nanmedian(emb.values)),
                            np.full((1,)+ls_t.shape[-2:], sin_d, dtype=np.float32),
                            np.full((1,)+ls_t.shape[-2:], cos_d, dtype=np.float32)], axis=0)
        xb = torch.from_numpy(x).unsqueeze(0).to(device, dtype=torch.float32)
        with torch.no_grad():
            yhat = model(xb)[0].cpu().numpy()

        da = xr.DataArray(yhat, dims=('band','y','x'), coords={'band': ls['band'].values, 'y': ls['y'], 'x': ls['x']})
        da.to_netcdf(os.path.join(args.out_dir, f'pred_{args.site}_{args.year}_{str(t)[:10].replace("-","")}.nc'))

if __name__ == '__main__':
    main()

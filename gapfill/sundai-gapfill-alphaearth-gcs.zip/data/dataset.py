import os, glob, math, random, warnings
from pathlib import Path
import numpy as np
import xarray as xr
import torch
from torch.utils.data import Dataset

def _open_mf(paths, storage_options=None, engine='h5netcdf'):
    files = []
    for p in paths:
        if p.startswith('gs://'):
            import fsspec
            fs = fsspec.filesystem('gcs', **(storage_options or {}))
            files.extend(fs.glob(p))
        else:
            files.extend(glob.glob(p))
    if not files:
        raise FileNotFoundError(f"No files matched: {paths}")
    backend_kwargs = {}
    if storage_options is not None:
        backend_kwargs['storage_options'] = storage_options
    ds = xr.open_mfdataset(files, combine='by_coords', engine=engine, backend_kwargs=backend_kwargs, chunks={})
    return ds

def _rescale_reflectance(arr, scale=10000.0):
    a = np.asarray(arr, dtype=np.float32) / float(scale)
    return np.clip(a, 0.0, 1.2)

class AlphaEarthGapfillDataset(Dataset):
    def __init__(self,
                 landsat_paths,
                 modis_paths,
                 embed_paths,
                 landsat_var='landsat_reflectance',
                 modis_var='modis_reflectance',
                 embed_var='embeddings',
                 bands=('red','nir','green','blue'),
                 patch=128,
                 simulate_modis_gaps=True,
                 modis_drop_prob=0.2,
                 seed=42,
                 gcs_auth='google_default'):
        super().__init__()
        random.seed(seed); np.random.seed(seed)

        if gcs_auth == 'google_default':
            storage_options = {'token': 'google_default'}
        elif gcs_auth == 'anon':
            storage_options = {'token': None}
        else:
            storage_options = {'token': gcs_auth}

        self.ls_ds = _open_mf(landsat_paths, storage_options=storage_options, engine='h5netcdf')
        self.md_ds = _open_mf(modis_paths,  storage_options=storage_options, engine='h5netcdf')
        self.eb_ds = _open_mf(embed_paths,  storage_options=storage_options, engine='h5netcdf')

        self.ls_var = landsat_var
        self.md_var = modis_var
        self.eb_var = embed_var
        self.bands = list(bands)
        self.patch = patch
        self.sim_modis = simulate_modis_gaps
        self.modis_drop_prob = modis_drop_prob

        self.samples = []
        self.time_index = self.ls_ds['time'].values

        for i, t in enumerate(self.time_index):
            ls_t = self.ls_ds[self.ls_var].sel(time=t)
            if np.all(np.isnan(ls_t)):
                continue
            self.samples.append(i)

    def __len__(self):
        return len(self.samples)

    def _choose_patch(self, H, W):
        ps = self.patch
        y0 = 0 if H<=ps else np.random.randint(0, H-ps)
        x0 = 0 if W<=ps else np.random.randint(0, W-ps)
        return slice(y0, y0+ps), slice(x0, x0+ps)

    def __getitem__(self, idx):
        i = self.samples[idx]
        t = self.time_index[i]

        ls = self.ls_ds[self.ls_var].sel(time=t)  # [band,y,x]
        ls = ls.sel(band=[b for b in self.bands if b in ls['band'].values])
        ls_np = _rescale_reflectance(ls.values)

        md = self.md_ds[self.md_var].sel(time=t)
        md_up = md.interp_like(ls, method='linear')
        md_np = _rescale_reflectance(md_up.values)

        if 'year' in self.eb_ds.coords:
            import pandas as pd
            yr = pd.to_datetime(str(t)).year
            eb = self.eb_ds[self.eb_var].sel(year=yr)
        else:
            eb = self.eb_ds[self.eb_var]
        eb_al = eb.interp_like(ls, method='nearest')
        eb_np = np.asarray(eb_al.values, dtype=np.float32)

        if self.sim_modis and random.random() < self.modis_drop_prob:
            h, w = md_np.shape[-2:]
            bh = max(16, h//6); bw = max(16, w//6)
            y0 = np.random.randint(0, h-bh); x0 = np.random.randint(0, w-bw)
            md_np[:, y0:y0+bh, x0:x0+bw] = np.nan

        H, W = ls_np.shape[-2:]
        ys, xs = self._choose_patch(H, W)
        ls_np = ls_np[:, ys, xs]; md_np = md_np[:, ys, xs]; eb_np = eb_np[:, ys, xs]

        def nan_to_med(a):
            if np.isnan(a).any():
                med = np.nanmedian(a, axis=(-2,-1), keepdims=True)
                a = np.where(np.isnan(a), med, a)
            return a
        md_np = nan_to_med(md_np); eb_np = nan_to_med(eb_np)

        import pandas as pd, numpy as np
        dt = pd.to_datetime(str(t))
        doy = dt.timetuple().tm_yday
        sin = np.full((1, ls_np.shape[1], ls_np.shape[2]), np.sin(2*np.pi*doy/365.0), dtype=np.float32)
        cos = np.full((1, ls_np.shape[1], ls_np.shape[2]), np.cos(2*np.pi*doy/365.0), dtype=np.float32)

        x = np.concatenate([md_np, eb_np, sin, cos], axis=0)
        y = ls_np
        return torch.from_numpy(x), torch.from_numpy(y)
